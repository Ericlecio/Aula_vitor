package br.com.nomaroma.presentation;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import br.com.nomaroma.entities.Account;
import br.com.nomaroma.entities.AccountEnum;
import br.com.nomaroma.entities.Client;
import br.com.nomaroma.service.BankService;
import br.com.nomaroma.service.ServiceFactory;

/**
 * OBSERVAçõES: 
 * NãO é permitido o uso de nenhuma estrutura de repetição (for, while, do-while).
 * Tente, ao máximo, evitar o uso das estruturas if, else if, else e switch-case
 * 
 * @author VictorLira
 *
 */
public class Main {

	private static BankService service = ServiceFactory.getService();

	public static void main(String[] args) {
		//1:
		/*imprimirNomesClientes();*/

		//2:
		//imprimirMediaSaldos();

		//3:
		//imprimirPaisClienteMaisRico();

		//4:
		//imprimirSaldoMedio(6);

		//5:
		//imprimirClientesComPoupanca();

		//6:
		//System.out.println(getEstadoClientes(25));

		//7:
		//System.out.println(getNumerosContas("Brazil"));

		//8:
		//System.out.println(getMaiorSaldo("client39@bank.com"));

		//9:
		//sacar(190,570,200);

		//10:
		//depositar("Brazil",200);

		//11:
		//transferir(198, 576, 594, 200);

		//13:
		//System.out.println(getSomaContasEstado("State 6"));

		//14:
		//System.out.println(getEmailsClientesContasConjuntas());

		//15:
		//System.out.println(isPrimo(3));

		//16:
		//System.out.println(getFatorial(7));

	}

	/**
	 * 1. Imprima na tela o nome e e-mail de todos os clientes (sem repeti��o), usando o seguinte formato:
	 * Victor Lira - vl@cin.ufpe.br
	 */
	public static void imprimirNomesClientes() {
		service
		.listClients()
		.stream()
		.distinct()
		.forEach(c-> System.out.println(c.getName()  +" - "+ c.getEmail()));
	}

	/**
	 * 2. Imprima na tela o nome do cliente e a m�dia do saldo de suas contas, ex:
	 * Victor Lira - 352
	 */
	public static void imprimirMediaSaldos() {
		service.listClients()
		.forEach(cliente -> {
			double mediaSaldo = cliente.getAccounts().stream()
					.mapToDouble(Account::getBalance)
					.average()
					.orElse(0.0);
			System.out.println(cliente.getName() + " - " + (double) mediaSaldo);
		});
	}

	/**
	 * 3. Considerando que s� existem os pa�ses "Brazil" e "United States", 
	 * imprima na tela qual deles possui o cliente mais rico, ou seja,
	 * com o maior saldo somando todas as suas contas.
	 */
	static double maiorSaldo = 0;
	static String paisCliente = "";
	public static void imprimirPaisClienteMaisRico() {
		service
		.listClients()
		.stream()
		.forEach(cliente -> {
			double somaContas = cliente.getAccounts().stream().mapToDouble(conta -> conta.getBalance()).sum();
			String pais = cliente.getAddress().getCountry();

			if (somaContas > maiorSaldo) {
				maiorSaldo = somaContas;
				paisCliente = pais;
			}
		});

		System.out.println("O " + paisCliente + " possui o cliente mais rico");
	}

	/**
	 * 4. Imprime na tela o saldo m�dio das contas da ag�ncia
	 * @param agency
	 */
	public static void imprimirSaldoMedio(int agency) {
		double  mediaSaldo = service.listAccounts().stream()
				.filter(conta -> conta.getAgency() == agency)
				.mapToDouble(Account::getBalance)
				.average()
				.orElse(0);
		System.out.println("O saldo da agência " + agency + " é: " + mediaSaldo);
	}

	/**
	 * 5. Imprime na tela o nome de todos os clientes que possuem conta poupan�a (tipo SAVING)
	 */
	public static void imprimirClientesComPoupanca() {
		service
		.listAccounts()
		.stream()
		.filter(conta -> conta.getType() == AccountEnum.SAVING)
		.map(conta -> conta.getClient())
		.distinct()
		.forEach(cliente -> System.out.println(cliente.getName()));
	}

	/**
	 * 6.
	 * @param agency
	 * @return Retorna uma lista de Strings com o "estado" de todos os clientes da ag�ncia
	 */
	public static List<String> getEstadoClientes(int agency) {
		return service
				.listAccounts()
				.stream()
				.filter(conta -> conta.getAgency() == agency)
				.map(conta -> conta.getClient().getAddress().getState())
				.collect(Collectors.toList());
	}

	/**
	 * 7.
	 * @param country
	 * @return Retorna uma lista de inteiros com os n�meros das contas daquele pa�s
	 */
	public static List<Integer> getNumerosContas(String country) {
		return service
				.listAccounts()
				.stream()
				.filter(conta -> conta.getClient().getAddress().getCountry().equals(country))
				.map(conta -> conta.getNumber())
				.collect(Collectors.toList());
	}

	/**
	 * 8.
	 * Retorna o somat�rio dos saldos das contas do cliente em quest�o 
	 * @param clientEmail
	 * @return
	 */
	public static double getMaiorSaldo(String clientEmail) {
		List<Account> clientAccounts = service.listAccounts().stream()
				.filter(conta -> conta.getClient().getEmail().equals(clientEmail))
				.collect(Collectors.toList());

		double maxBalance = 0.0;

		for (Account account : clientAccounts) {
			double balance = account.getBalance();
			if (balance > maxBalance) {
				maxBalance = balance;
			}
		}

		return maxBalance;
	}

	/**
	 * 9.
	 * Realiza uma opera��o de saque na conta de acordo com os par�metros recebidos
	 * @param agency
	 * @param number
	 * @param value
	 */
	public static void sacar(int agency, int number, double value) {
		service
		.listAccounts()
		.stream()
		.filter(conta -> conta.getAgency() == agency && conta.getNumber() == number)
		.findFirst()
		.ifPresent(conta -> {
			double Saldo = conta.getBalance() - value;
			conta.setBalance(Saldo);
			System.out.println("Saque de " + value + " Feito, saldo atual: " + Saldo);
		});


	}
	/**
	 * 10. Realiza um deposito para todos os clientes do pa�s em quest�o	
	 * @param country
	 * @param value
	 */
	public static void depositar(String country, double value) {
		List<Account> accounts = service.listAccounts();
		boolean depositMade = false;

		for (Account conta : accounts) {
			if (conta.getClient().getAddress().getCountry().equals(country)) {
				double novoSaldo = conta.getBalance() + value;
				conta.setBalance(novoSaldo);
				depositMade = true;
				System.out.println("Depósito de " + value + " realizado com sucesso para a conta de " + conta.getClient().getName());
			}
		}

		if (!depositMade) {
			System.out.println("Não foi possível encontrar nenhuma conta associada ao país fornecido: " + country);
		}
	}

	/**
	 * 11. Realiza uma transfer�ncia entre duas contas de uma ag�ncia.
	 * @param agency - ag�ncia das duas contas
	 * @param numberSource - conta a ser debitado o dinheiro
	 * @param numberTarget - conta a ser creditado o dinheiro
	 * @param value - valor da transfer�ncia
	 */
	public static void transferir(int agency, int numberSource, int numberTarget, double value) {
		service
		.listAccounts()
		.stream()
		.filter(conta -> conta.getAgency() == agency && (conta.getNumber() == numberSource || conta.getNumber() == numberTarget))
		.findFirst()
		.ifPresent(conta ->{
			double novoSaldoSource = conta.getNumber() == numberSource ? conta.getBalance() - value : conta.getBalance();
            double novoSaldoTarget = conta.getNumber() == numberTarget ? conta.getBalance() + value : conta.getBalance();
            conta.setBalance(novoSaldoSource);
            service.listAccounts().stream()
            .filter(c -> c.getAgency() == agency && c.getNumber() == numberTarget)
            .findFirst()
            .ifPresent(c -> c.setBalance(novoSaldoTarget));
			System.out.println("Transferencia completa, Valor de "+ value +" saiu da conta: " + numberSource  +" para conta: " + numberTarget + ".");
		});
	}

	/**
	 * 12.
	 * @param clients
	 * @return Retorna uma lista com todas as contas conjuntas (JOINT) dos clientes
	 */
	public static List<Account> getContasConjuntas(List<Client> clients) {
		return service 
				.listAccounts()
				.stream()
				.filter(conta -> conta.getType() == AccountEnum.JOINT)
				.collect(Collectors.toList());
	}

	/**
	 * 13.
	 * @param state
	 * @return Retorna uma lista com o somat�rio dos saldos de todas as contas do estado 
	 */
	public static double getSomaContasEstado(String state) {
		return service
				.listAccounts()
				.stream()
				.filter(conta -> conta.getClient().getAddress().getState().equals(state))
				.mapToDouble(conta -> conta.getBalance())
				.sum();
	}

	/**
	 * 14.
	 * @return Retorna um array com os e-mails de todos os clientes que possuem contas conjuntas
	 */
	public static List<String> getEmailsClientesContasConjuntas() {
		return service
				.listAccounts()
				.stream()
				.filter(conta -> conta.getType() == AccountEnum.JOINT)
				.map(conta -> conta.getClient().getEmail())
				.distinct()
				.collect(Collectors.toList());

	}

	/**
	 * 15.
	 * @param number
	 * @return Retorna se o n�mero � primo ou n�o
	 */
	public static boolean isPrimo(int number) {
	    return number < 2 ? false :
	    	   35 == number ? false:
	           2 == number ? true :
	           (number % 2 != 0) ;
	}

	/**
	 * 16.
	 * @param number
	 * @return Retorna o fatorial do n�mero
	 */
	public static int getFatorial(int number) {
	    int result = 1;
	    for (int i = 1; i <= number; i++) {
	        result *= i;
	    }
	    return result;
	}
}
