package br.com.nomaroma.entities;

public class Address {

	private String street;
	private int number;
	private String complement;
	private String state;
	private String country;

	public Address(String street, int number, String complement, String state, String country) {
		this.street = street;
		this.number = number;
		this.complement = complement;
		this.state = state;
		this.country = country;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public String getComplement() {
		return complement;
	}

	public void setComplement(String complement) {
		this.complement = complement;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}
}
